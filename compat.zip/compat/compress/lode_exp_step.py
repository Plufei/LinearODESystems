print('loaded')
import math
def G(a,b):
 a=abs(int(a));b=abs(int(b))
 while b:a,b=b,a%b
 return a or 1
def F(n,d=1):
 n=int(n);d=int(d)
 if d==0:raise Exception('zero den')
 if n==0:return (0,1)
 if d<0:n=-n;d=-d
 g=G(n,d);return (n//g,d//g)
def P(s):
 s=s.strip()
 if '/' in s:
  a=s.split('/');return F(a[0],a[1])
 if '.' in s:
  neg=s[0]=='-'
  if neg:s=s[1:]
  a=s.split('.');den=10**len(a[1]);num=int(a[0] or '0')*den+int(a[1])
  if neg:num=-num
  return F(num,den)
 return F(s,1)
def S(x):
 if x[0]==0:return '0'
 if x[1]==1:return str(x[0])
 return str(x[0])+'/'+str(x[1])
def A(x,y):return F(x[0]*y[1]+y[0]*x[1],x[1]*y[1])
def B(x,y):return F(x[0]*y[1]-y[0]*x[1],x[1]*y[1])
def M(x,y):return F(x[0]*y[0],x[1]*y[1])
def D(x,y):return F(x[0]*y[1],x[1]*y[0])
def N(x):return (-x[0],x[1])
def Z(x):return x[0]==0
def E(x,y):return x[0]*y[1]==y[0]*x[1]
def Fl(x):return x[0]/x[1]
def FV(v):
 r='['
 for i in range(len(v)):
  if i:r+=', '
  r+=S(v[i])
 return r+']'
def FM(X):
 for r in X:print(' '+FV(r))
def RD(n,p):
 while 1:
  q=input(p).split()
  if len(q)==n:return [P(x) for x in q]
  print('need '+str(n))
def RM(n):
 r=[]
 print('Enter A row by row.')
 for i in range(n):r.append(RD(n,'row '+str(i+1)+': '))
 return r
def I(n):
 r=[]
 for i in range(n):
  row=[]
  for j in range(n):row.append(F(1) if i==j else F(0))
  r.append(row)
 return r
def SUB(X,Y):
 r=[]
 for i in range(len(X)):
  row=[]
  for j in range(len(X[0])):row.append(B(X[i][j],Y[i][j]))
  r.append(row)
 return r
def SM(c,X):
 return [[M(c,X[i][j]) for j in range(len(X[0]))] for i in range(len(X))]
def DET2(X):return B(M(X[0][0],X[1][1]),M(X[0][1],X[1][0]))
def DET3(X):
 a,b,c=X[0];d,e,f=X[1];g,h,k=X[2]
 return A(B(M(a,B(M(e,k),M(f,h))),M(b,B(M(d,k),M(f,g)))),M(c,B(M(d,h),M(e,g))))
def RREF(T):
 T=[x[:] for x in T];r=0;m=len(T);n=len(T[0])
 for c in range(n-1):
  p=-1
  for i in range(r,m):
   if not Z(T[i][c]):p=i;break
  if p<0:continue
  T[r],T[p]=T[p],T[r];pv=T[r][c]
  for j in range(n):T[r][j]=D(T[r][j],pv)
  for i in range(m):
   if i!=r and not Z(T[i][c]):
    q=T[i][c]
    for j in range(n):T[i][j]=B(T[i][j],M(q,T[r][j]))
  r+=1
 return T
def SOL(X,b):
 m=len(X);n=len(X[0]);T=[X[i][:]+[b[i]] for i in range(m)]
 print('Augmented matrix before RREF:')
 FM(T)
 R=RREF(T)
 print('RREF:')
 FM(R)
 p={}
 for i in range(m):
  allz=1
  for j in range(n):
   if not Z(R[i][j]):allz=0;p[j]=i;break
  if allz and not Z(R[i][n]):return ('none',[])
 free=[]
 for j in range(n):
  if j not in p:free.append(j)
 if not free:
  x=[F(0) for i in range(n)]
  for j in p:x[j]=R[p[j]][n]
  return ('one',x)
 part=[F(0) for i in range(n)]
 for j in p:part[j]=R[p[j]][n]
 bas=[]
 for fc in free:
  v=[F(0) for i in range(n)];v[fc]=F(1)
  for pc in p:v[pc]=N(R[p[pc]][fc])
  bas.append(v)
 return ('free',[part,bas])
def NS(X):
 print('Solve nullspace:')
 t,r=SOL(X,[F(0) for i in range(len(X))])
 if t=='free':return r[1]
 return []
def C2(X):return [F(1),N(A(X[0][0],X[1][1])),DET2(X)]
def C3(X):
 tr=A(A(X[0][0],X[1][1]),X[2][2])
 s=A(A(B(M(X[1][1],X[2][2]),M(X[1][2],X[2][1])),B(M(X[0][0],X[2][2]),M(X[0][2],X[2][0]))),B(M(X[0][0],X[1][1]),M(X[0][1],X[1][0])))
 return [F(1),N(tr),s,N(DET3(X))]
def CE(co):
 if len(co)==3:return 'lambda^2+('+S(co[1])+')lambda+('+S(co[2])+')=0'
 return 'lambda^3+('+S(co[1])+')lambda^2+('+S(co[2])+')lambda+('+S(co[3])+')=0'
def PE(co,x):
 v=F(0)
 for c in co:v=A(M(v,x),c)
 return v
def PD(co,x):
 o=[];v=F(0)
 for c in co:v=A(M(v,x),c);o.append(v)
 return o[:-1]
def Q(a,b,c):
 di=B(M(b,b),M(F(4),M(a,c)))
 if di[0]<0:return []
 sq=int(math.sqrt(di[0]*di[1]))
 sd=F(sq,di[1]) if sq*sq==di[0]*di[1] else F(int(math.sqrt(Fl(di))*1000),1000)
 return [D(A(N(b),sd),M(F(2),a)),D(B(N(b),sd),M(F(2),a))]
def RTS(co):
 co=co[:];out=[]
 while len(co)>1:
  d=len(co)-1
  if d==1:out.append(D(N(co[1]),co[0]));break
  if d==2:out+=Q(co[0],co[1],co[2]);break
  f=None;lim=abs(co[-1][0]) or 1
  for k in range(-lim,lim+1):
   if k and Z(PE(co,F(k))):f=F(k);break
  if f is None:break
  print('Found root lambda='+S(f))
  co=PD(co,f)
  print('Reduced polynomial coefficients: '+FV(co))
  out.append(f)
 return out
def EIG(X):
 co=C2(X) if len(X)==2 else C3(X)
 print('Characteristic equation:')
 print(CE(co))
 print('Solve for lambda roots.')
 return RTS(co)
def EV(X,l):
 print('Find eigenvector for lambda='+S(l))
 print('Solve (A-lambda I)v=0.')
 Bm=SUB(X,SM(l,I(len(X))))
 print('A-lambda I:')
 FM(Bm)
 ns=NS(Bm)
 if ns:
  print('v='+FV(ns[0]))
  return ns[0]
 print('no eigenvector found')
 return [F(0) for i in range(len(X))]
def EX(l):
 if Z(l):return ''
 if E(l,F(1)):return 'e^t'
 return 'e^('+S(l)+'t)'
def HOM(X,pr):
 if pr:
  print('')
  print('STEP 1: Solve homogeneous part')
  print('Xprime=AX')
  print('A=')
  FM(X)
 vals=EIG(X)
 parts=[];ci=1
 if pr:print('Use X=C v e^(lambda t) for each eigenpair.')
 for l in vals:
  v=EV(X,l)
  if pr:
   print('Term '+str(ci)+': C'+str(ci)+FV(v)+EX(l))
  parts.append('C'+str(ci)+FV(v)+EX(l));ci+=1
 ans='Xh(t)='+'+'.join(parts)
 if pr:
  print('Homogeneous solution:')
  print(ans)
 return ans,vals
def COMP(X,vals,p,k,kind):
 print('')
 print('STEP 4: Component form')
 nm=['x(t)','y(t)','z(t)']
 for r in range(len(X)):
  parts=[];ci=1
  for l in vals:
   v=EV(X,l);c=v[r]
   if not Z(c):
    if E(c,F(1)):parts.append('C'+str(ci)+EX(l))
    else:parts.append(S(c)+'C'+str(ci)+EX(l))
   ci+=1
  if kind=='exp' and not Z(p[r]):parts.append(S(p[r])+'e^('+S(k)+'t)')
  if kind=='const' and not Z(p[r]):parts.append(S(p[r]))
  print(nm[r]+'='+'+'.join(parts).replace('+-','-'))

def MAIN():
 print('linear exponential forcing solver')
 n=int(input('dim 2/3: '))
 X=RM(n)
 k=P(input('k in e^(kt): '))
 b=RD(n,'b vector: ')
 print('')
 print('Original problem: Xprime=AX+b e^(kt)')
 print('b='+FV(b))
 print('k='+S(k))
 h,vals=HOM(X,1)
 print('')
 print('STEP 2: Check resonance')
 print('Resonance happens if k equals an eigenvalue.')
 r=0
 for l in vals:
  print('compare k='+S(k)+' with lambda='+S(l))
  if E(l,k):r=1
 if r:
  print('Resonance found.')
  print('Use a t-multiplied trial such as Xp=(t p+q)e^(kt).')
  print('This small calculator file stops after setup.')
  return
 print('No resonance.')
 print('')
 print('STEP 3: Find particular solution')
 print('Because forcing is b e^(kt), try:')
 print('Xp=p e^(kt)')
 print('Differentiate:')
 print('Xpprime=k p e^(kt)')
 print('Substitute into Xprime=AX+b e^(kt):')
 print('k p e^(kt)=A p e^(kt)+b e^(kt)')
 print('Divide by e^(kt):')
 print('k p=Ap+b')
 print('Move Ap to left:')
 print('(kI-A)p=b')
 Bm=SUB(SM(k,I(n)),X)
 print('kI-A=')
 FM(Bm)
 t,p=SOL(Bm,b)
 if t=='free':p=p[0]
 if t=='none':
  print('No particular solution found.');return
 print('p='+FV(p))
 xp=FV(p)+'e^('+S(k)+'t)'
 print('Xp(t)='+xp)
 print('')
 print('STEP 4: Add solutions')
 print('X(t)=Xh(t)+Xp(t)')
 print('X(t)='+h[6:]+'+'+xp)
 COMP(X,vals,p,k,'exp')
MAIN()
