print('triode loaded')
# TRIANGULAR ODE SOLVER, BOTTOM-UP METHOD
# Nspire-compatible. No numpy/sympy.
# Solves upper triangular systems:
# Xprime = A X + b e^(kt)
# For constant forcing, use k=0.

def G(a,b):
 a=abs(int(a));b=abs(int(b))
 while b:a,b=b,a%b
 return a or 1
def F(n,d=1):
 n=int(n);d=int(d)
 if d==0:raise Exception('zero den')
 if n==0:return (0,1)
 if d<0:n=-n;d=-d
 g=G(n,d);return (n//g,d//g)
def P(s):
 s=s.strip()
 if '/' in s:
  a=s.split('/');return F(a[0],a[1])
 if '.' in s:
  neg=s[0]=='-'
  if neg:s=s[1:]
  a=s.split('.');den=10**len(a[1]);num=int(a[0] or '0')*den+int(a[1])
  if neg:num=-num
  return F(num,den)
 return F(s,1)
def S(x):
 if x[0]==0:return '0'
 if x[1]==1:return str(x[0])
 return str(x[0])+'/'+str(x[1])
def A(x,y):return F(x[0]*y[1]+y[0]*x[1],x[1]*y[1])
def B(x,y):return F(x[0]*y[1]-y[0]*x[1],x[1]*y[1])
def M(x,y):return F(x[0]*y[0],x[1]*y[1])
def D(x,y):return F(x[0]*y[1],x[1]*y[0])
def N(x):return (-x[0],x[1])
def Z(x):return x[0]==0
def E(x,y):return x[0]*y[1]==y[0]*x[1]
def RD(n,p):
 while 1:
  q=input(p).split()
  if len(q)==n:return [P(x) for x in q]
  print('need '+str(n))
def RM(n):
 r=[]
 print('Enter upper triangular A row by row.')
 for i in range(n):r.append(RD(n,'row '+str(i+1)+': '))
 return r
def FV(v):
 r='['
 for i in range(len(v)):
  if i:r+=', '
  r+=S(v[i])
 return r+']'
def FM(X):
 for r in X:print(' '+FV(r))
def EX(rate):
 if Z(rate):return ''
 if E(rate,F(1)):return 'e^t'
 return 'e^('+S(rate)+'t)'
def POW(p):
 if p==0:return ''
 if p==1:return 't'
 return 't^'+str(p)

# term = [coef, cname, power, rate]
# means coef*cname*t^power*e^(rate*t)
# cname is '' for no constant, or 'C1', 'C2', etc.

def term(co,c,p,r):return [co,c,p,r]
def copy_terms(ts):
 out=[]
 for x in ts:out.append([x[0],x[1],x[2],x[3]])
 return out
def add_term(ts,t):
 if Z(t[0]):return ts
 for x in ts:
  if x[1]==t[1] and x[2]==t[2] and E(x[3],t[3]):
   x[0]=A(x[0],t[0])
   return ts
 ts.append(t)
 return ts
def add_terms(a,b):
 out=copy_terms(a)
 for t in b:add_term(out,t)
 return clean(out)
def scale_terms(c,ts):
 out=[]
 for t in ts:add_term(out,term(M(c,t[0]),t[1],t[2],t[3]))
 return clean(out)
def clean(ts):
 out=[]
 for t in ts:
  if not Z(t[0]):out.append(t)
 return out
def fmt_coef(c,hasbody):
 if E(c,F(1)) and hasbody:return ''
 if E(c,F(-1)) and hasbody:return '-'
 return S(c)
def fmt_term(t):
 co,c,p,r=t
 body=''
 if c!='':body+=c
 body+=POW(p)
 body+=EX(r)
 if body=='':body='1'
 cf=fmt_coef(co,body!='1')
 if body=='1':return S(co)
 return cf+body
def fmt_terms(ts):
 ts=clean(ts)
 if len(ts)==0:return '0'
 s=''
 for i in range(len(ts)):
  u=fmt_term(ts[i])
  if i==0:s+=u
  else:
   if u.startswith('-'):s+=' - '+u[1:]
   else:s+=' + '+u
 return s

def scalar_particular(a,forcing):
 # solve yprime = a y + forcing
 # yprime-a y = forcing
 # returns particular terms
 out=[]
 for t in forcing:
  co,c,p,r=t
  if E(r,a):
   # resonance: y_p = co/(p+1) * cname * t^(p+1) e^(a t)
   add_term(out,term(D(co,F(p+1)),c,p+1,r))
  else:
   # solve recursively for e^(rt) polynomial.
   # For p=0: q0 = co/(r-a)
   # For p>0, polynomial coefficients are found from high to low.
   den=B(r,a)
   coeff=[F(0) for i in range(p+1)]
   coeff[p]=D(co,den)
   j=p-1
   while j>=0:
    # (r-a)q_j + (j+1)q_(j+1) = 0
    coeff[j]=D(N(M(F(j+1),coeff[j+1])),den)
    j-=1
   for j in range(p+1):
    add_term(out,term(coeff[j],c,j,r))
 return clean(out)

def solve_bottom(A,b,k):
 n=len(A)
 names=['x','y','z']
 sols=[[] for i in range(n)]
 print('')
 print('Original system:')
 print('Xprime = A X + b e^(kt)')
 print('A=');FM(A)
 print('b='+FV(b))
 print('k='+S(k))
 print('')
 print('Bottom-up idea:')
 print('Start with last equation.')
 print('Then substitute known lower variables upward.')
 print('')
 ci=n
 for i in range(n-1,-1,-1):
  var=names[i]
  print('STEP '+str(n-i)+': solve for '+var+'(t)')
  print('Equation:')
  line=var+'prime = '+S(A[i][i])+var
  for j in range(i+1,n):
   if not Z(A[i][j]):line+=' + '+S(A[i][j])+names[j]
  if not Z(b[i]):line+=' + '+S(b[i])+'e^('+S(k)+'t)'
  print(line.replace('+ -','- '))
  forcing=[]
  if not Z(b[i]):add_term(forcing,term(b[i],'',0,k))
  for j in range(i+1,n):
   if not Z(A[i][j]):
    print('Substitute '+names[j]+'(t) = '+fmt_terms(sols[j]))
    forcing=add_terms(forcing,scale_terms(A[i][j],sols[j]))
  print('After substitution:')
  print(var+'prime - '+S(A[i][i])+var+' = '+fmt_terms(forcing))
  cname='C'+str(ci)
  hom=[term(F(1),cname,0,A[i][i])]
  print('Homogeneous part: '+cname+EX(A[i][i]))
  part=scalar_particular(A[i][i],forcing)
  print('Particular part: '+fmt_terms(part))
  sols[i]=add_terms(hom,part)
  print(var+'(t) = '+fmt_terms(sols[i]))
  print('')
  ci-=1
 print('FINAL ANSWER')
 for i in range(n):
  print(names[i]+'(t) = '+fmt_terms(sols[i]))

def check_upper(A):
 for i in range(len(A)):
  for j in range(i):
   if not Z(A[i][j]):return 0
 return 1

def MAIN():
 print('TRIANGULAR BOTTOM-UP ODE SOLVER')
 print('Solves upper triangular Xprime=AX+b e^(kt).')
 print('For constant b, use k=0.')
 n=int(input('dimension 2 or 3: '))
 A=RM(n)
 if not check_upper(A):
  print('A is not upper triangular.')
  print('Bottom-up method needs zeros below diagonal.')
  return
 k=P(input('k in e^(kt), use 0 for constant: '))
 b=RD(n,'b vector: ')
 solve_bottom(A,b,k)
MAIN()
