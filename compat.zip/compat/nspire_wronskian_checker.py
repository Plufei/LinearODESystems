# NSPIRE WRONSKIAN CHECKER
# No numpy, no sympy, no scipy.
# Use on TI-Nspire CX II Python.
# Enter functions using t, sin(t), cos(t), e^(2t), t*e^(2t), t^2.

import math

EPS = 0.000000001

class Expr:
    def eval(self, t):
        return 0.0
    def deriv(self):
        return Const(0)
    def simp(self):
        return self
    def __add__(self, other):
        return Add([self, to_expr(other)]).simp()
    def __sub__(self, other):
        return Add([self, Mul([Const(-1), to_expr(other)])]).simp()
    def __mul__(self, other):
        return Mul([self, to_expr(other)]).simp()
    def __neg__(self):
        return Mul([Const(-1), self]).simp()

class Const(Expr):
    def __init__(self, value):
        self.value = float(value)
    def eval(self, t):
        return self.value
    def deriv(self):
        return Const(0)
    def simp(self):
        if abs(self.value) < EPS:
            return Const(0)
        return self
    def __str__(self):
        r = round(self.value)
        if abs(self.value - r) < EPS:
            return str(int(r))
        return str(round(self.value, 6))

class Var(Expr):
    def eval(self, t):
        return t
    def deriv(self):
        return Const(1)
    def __str__(self):
        return "t"

class Add(Expr):
    def __init__(self, terms):
        self.terms = terms
    def eval(self, t):
        s = 0.0
        for a in self.terms:
            s = s + a.eval(t)
        return s
    def deriv(self):
        out = []
        for a in self.terms:
            out.append(a.deriv())
        return Add(out).simp()
    def simp(self):
        out = []
        c = 0.0
        for a in self.terms:
            a = a.simp()
            if isinstance(a, Add):
                for b in a.terms:
                    out.append(b)
            elif isinstance(a, Const):
                c = c + a.value
            else:
                out.append(a)
        if abs(c) > EPS:
            out.append(Const(c))
        if len(out) == 0:
            return Const(0)
        if len(out) == 1:
            return out[0]
        self.terms = out
        return self
    def __str__(self):
        s = ""
        for i in range(len(self.terms)):
            part = str(self.terms[i])
            if i == 0:
                s = s + part
            else:
                if part.startswith("-"):
                    s = s + " - " + part[1:]
                else:
                    s = s + " + " + part
        return s

class Mul(Expr):
    def __init__(self, factors):
        self.factors = factors
    def eval(self, t):
        p = 1.0
        for a in self.factors:
            p = p * a.eval(t)
        return p
    def deriv(self):
        # Product rule
        terms = []
        n = len(self.factors)
        for i in range(n):
            fs = []
            for j in range(n):
                if i == j:
                    fs.append(self.factors[j].deriv())
                else:
                    fs.append(self.factors[j])
            terms.append(Mul(fs))
        return Add(terms).simp()
    def simp(self):
        out = []
        c = 1.0
        for a in self.factors:
            a = a.simp()
            if isinstance(a, Mul):
                for b in a.factors:
                    out.append(b)
            elif isinstance(a, Const):
                c = c * a.value
            else:
                out.append(a)
        if abs(c) < EPS:
            return Const(0)
        if abs(c - 1.0) > EPS:
            out.insert(0, Const(c))
        if len(out) == 0:
            return Const(1)
        if len(out) == 1:
            return out[0]
        self.factors = out
        return self
    def __str__(self):
        out = []
        for a in self.factors:
            if isinstance(a, Add):
                out.append("(" + str(a) + ")")
            else:
                out.append(str(a))
        return "*".join(out)

class Pow(Expr):
    def __init__(self, base, power):
        self.base = base
        self.power = int(power)
    def eval(self, t):
        return self.base.eval(t) ** self.power
    def deriv(self):
        if self.power == 0:
            return Const(0)
        return Mul([Const(self.power), Pow(self.base, self.power - 1), self.base.deriv()]).simp()
    def simp(self):
        b = self.base.simp()
        if self.power == 0:
            return Const(1)
        if self.power == 1:
            return b
        if isinstance(b, Const):
            return Const(b.value ** self.power)
        self.base = b
        return self
    def __str__(self):
        if isinstance(self.base, Add):
            return "(" + str(self.base) + ")^" + str(self.power)
        return str(self.base) + "^" + str(self.power)

class Sin(Expr):
    def __init__(self, arg):
        self.arg = arg
    def eval(self, t):
        return math.sin(self.arg.eval(t))
    def deriv(self):
        return Mul([Cos(self.arg), self.arg.deriv()]).simp()
    def simp(self):
        self.arg = self.arg.simp()
        return self
    def __str__(self):
        return "sin(" + str(self.arg) + ")"

class Cos(Expr):
    def __init__(self, arg):
        self.arg = arg
    def eval(self, t):
        return math.cos(self.arg.eval(t))
    def deriv(self):
        return Mul([Const(-1), Sin(self.arg), self.arg.deriv()]).simp()
    def simp(self):
        self.arg = self.arg.simp()
        return self
    def __str__(self):
        return "cos(" + str(self.arg) + ")"

class Exp(Expr):
    def __init__(self, arg):
        self.arg = arg
    def eval(self, t):
        return math.exp(self.arg.eval(t))
    def deriv(self):
        return Mul([Exp(self.arg), self.arg.deriv()]).simp()
    def simp(self):
        self.arg = self.arg.simp()
        return self
    def __str__(self):
        return "e^(" + str(self.arg) + ")"

def to_expr(x):
    if isinstance(x, Expr):
        return x
    return Const(x)

class Parser:
    def __init__(self, text):
        text = text.replace(" ", "")
        text = text.replace("pi", str(math.pi))
        self.text = text
        self.i = 0
    def peek(self):
        if self.i >= len(self.text):
            return ""
        return self.text[self.i]
    def eat(self, ch):
        if self.peek() == ch:
            self.i = self.i + 1
            return True
        return False
    def parse(self):
        e = self.parse_sum()
        if self.i != len(self.text):
            raise Exception("Bad input near " + self.text[self.i:])
        return e.simp()
    def parse_sum(self):
        e = self.parse_prod()
        while True:
            if self.eat("+"):
                e = Add([e, self.parse_prod()]).simp()
            elif self.eat("-"):
                e = Add([e, Mul([Const(-1), self.parse_prod()])]).simp()
            else:
                break
        return e
    def parse_prod(self):
        fs = [self.parse_pow()]
        while True:
            if self.eat("*"):
                fs.append(self.parse_pow())
            elif self.eat("/"):
                fs.append(Pow(self.parse_pow(), -1))
            else:
                c = self.peek()
                if c == "t" or c == "(" or c.isalpha():
                    fs.append(self.parse_pow())
                else:
                    break
        return Mul(fs).simp()
    def parse_pow(self):
        e = self.parse_unary()
        while self.eat("^"):
            p = self.parse_unary()
            if isinstance(e, Const) and abs(e.value - math.e) < EPS:
                e = Exp(p).simp()
            elif isinstance(p, Const):
                e = Pow(e, int(round(p.value))).simp()
            else:
                raise Exception("Only integer powers supported, except e^(...)")
        return e
    def parse_unary(self):
        if self.eat("+"):
            return self.parse_unary()
        if self.eat("-"):
            return Mul([Const(-1), self.parse_unary()]).simp()
        return self.parse_atom()
    def parse_atom(self):
        c = self.peek()
        if c == "(":
            self.eat("(")
            e = self.parse_sum()
            if not self.eat(")"):
                raise Exception("Missing )")
            return e
        if c.isdigit() or c == ".":
            return self.parse_num()
        if self.text.startswith("sin", self.i):
            self.i = self.i + 3
            return Sin(self.parse_arg()).simp()
        if self.text.startswith("cos", self.i):
            self.i = self.i + 3
            return Cos(self.parse_arg()).simp()
        if self.text.startswith("exp", self.i):
            self.i = self.i + 3
            return Exp(self.parse_arg()).simp()
        if self.text.startswith("e", self.i):
            self.i = self.i + 1
            return Const(math.e)
        if self.text.startswith("t", self.i):
            self.i = self.i + 1
            return Var()
        raise Exception("Bad char near " + self.text[self.i:])
    def parse_arg(self):
        if self.eat("("):
            e = self.parse_sum()
            if not self.eat(")"):
                raise Exception("Missing )")
            return e
        return self.parse_atom()
    def parse_num(self):
        start = self.i
        while self.peek().isdigit() or self.peek() == ".":
            self.i = self.i + 1
        return Const(float(self.text[start:self.i]))

def parse_expr(s):
    return Parser(s).parse()

def det_sym(M):
    n = len(M)
    if n == 1:
        return M[0][0].simp()
    if n == 2:
        return (M[0][0]*M[1][1] - M[0][1]*M[1][0]).simp()
    total = Const(0)
    for c in range(n):
        minor = []
        for i in range(1, n):
            row = []
            for j in range(n):
                if j != c:
                    row.append(M[i][j])
            minor.append(row)
        term = M[0][c] * det_sym(minor)
        if c % 2 == 1:
            term = -term
        total = total + term
    return total.simp()

def wronskian_matrix(funcs):
    n = len(funcs)
    rows = []
    cur = funcs[:]
    for i in range(n):
        rows.append(cur[:])
        new = []
        for f in cur:
            new.append(f.deriv().simp())
        cur = new
    return rows

def print_matrix(M):
    for row in M:
        s = "["
        for j in range(len(row)):
            if j > 0:
                s = s + ", "
            s = s + str(row[j])
        s = s + "]"
        print(s)

def check_wronskian(texts):
    funcs = []
    for s in texts:
        funcs.append(parse_expr(s))
    print("")
    print("STEP 1: functions")
    for i in range(len(funcs)):
        print("f" + str(i+1) + "(t) = " + str(funcs[i]))
    print("")
    print("STEP 2: Wronskian matrix")
    Wm = wronskian_matrix(funcs)
    print_matrix(Wm)
    print("")
    print("STEP 3: determinant")
    W = det_sym(Wm)
    print("W(t) = " + str(W))
    print("")
    print("STEP 4: numeric check")
    pts = [-3, -2, -1, 0, 1, 2, 3]
    found = False
    for t in pts:
        try:
            v = W.eval(t)
            print("W(" + str(t) + ") = " + str(round(v, 8)))
            if abs(v) > 0.000001:
                found = True
        except:
            pass
    print("")
    print("CONCLUSION")
    if found:
        print("W(t) is not identically zero.")
        print("The functions are linearly independent.")
    else:
        print("All tested values were zero.")
        print("The Wronskian test is inconclusive.")
        print("For many class problems this means dependent,")
        print("but be careful with unusual functions.")

def menu():
    while True:
        print("")
        print("WRONSKIAN CHECKER")
        print("1 Enter functions")
        print("2 Example cos(t), sin(t)")
        print("3 Example e^(2t), t*e^(2t), t^2*e^(2t)")
        print("4 Quit")
        ch = input("Choice: ")
        if ch == "1":
            try:
                n = int(input("How many functions? "))
                texts = []
                print("Use t, sin(t), cos(t), e^(2t), t*e^(2t)")
                for i in range(n):
                    texts.append(input("f" + str(i+1) + "(t) = "))
                check_wronskian(texts)
            except Exception as e:
                print("Error: " + str(e))
        elif ch == "2":
            check_wronskian(["cos(t)", "sin(t)"])
        elif ch == "3":
            check_wronskian(["e^(2t)", "t*e^(2t)", "t^2*e^(2t)"])
        elif ch == "4":
            break
        else:
            print("Bad choice")

menu()
