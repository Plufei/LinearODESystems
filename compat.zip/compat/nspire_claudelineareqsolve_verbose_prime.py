# NSPIRE VERBOSE LINEAR SYSTEM ODE SOLVER
# No numpy, no sympy, no scipy.
# Supports many classroom 2x2 and 3x3 linear systems:
#   Xprime = AX
#   Xprime = AX + b
#   Xprime = AX + b e^(kt)
#   repeated real eigenvalues, generalized eigenvectors
#   simple exact fractions
#
# Use plain ASCII input. Example row: 1 7
# Fractions allowed: -3/2

import math

# ---------------- FRACTIONS ----------------

def igcd(a, b):
    a = abs(int(a))
    b = abs(int(b))
    while b != 0:
        a, b = b, a % b
    if a == 0:
        return 1
    return a

def F(n, d):
    n = int(n)
    d = int(d)
    if d == 0:
        raise Exception("division by zero")
    if n == 0:
        return (0, 1)
    if d < 0:
        n = -n
        d = -d
    g = igcd(n, d)
    return (n // g, d // g)

def Fi(n):
    return (int(n), 1)

def fadd(a, b):
    return F(a[0]*b[1] + b[0]*a[1], a[1]*b[1])

def fsub(a, b):
    return F(a[0]*b[1] - b[0]*a[1], a[1]*b[1])

def fmul(a, b):
    return F(a[0]*b[0], a[1]*b[1])

def fdiv(a, b):
    if b[0] == 0:
        raise Exception("division by zero")
    return F(a[0]*b[1], a[1]*b[0])

def fneg(a):
    return (-a[0], a[1])

def fis0(a):
    return a[0] == 0

def feq(a, b):
    return a[0]*b[1] == b[0]*a[1]

def ffloat(a):
    return float(a[0]) / float(a[1])

def fs(a):
    if a[0] == 0:
        return "0"
    if a[1] == 1:
        return str(a[0])
    return str(a[0]) + "/" + str(a[1])

def parse_frac(s):
    s = s.strip()
    if "/" in s:
        p = s.split("/")
        return F(int(p[0]), int(p[1]))
    if "." in s:
        neg = False
        if s.startswith("-"):
            neg = True
            s = s[1:]
        p = s.split(".")
        whole = p[0]
        dec = p[1]
        if whole == "":
            whole = "0"
        den = 10 ** len(dec)
        num = int(whole) * den + int(dec)
        if neg:
            num = -num
        return F(num, den)
    return Fi(int(s))

# ---------------- MATRIX ----------------

def zero(n, m):
    return [[Fi(0) for j in range(m)] for i in range(n)]

def ident(n):
    A = zero(n, n)
    for i in range(n):
        A[i][i] = Fi(1)
    return A

def msub(A, B):
    n = len(A)
    m = len(A[0])
    C = zero(n, m)
    for i in range(n):
        for j in range(m):
            C[i][j] = fsub(A[i][j], B[i][j])
    return C

def smul(c, A):
    n = len(A)
    m = len(A[0])
    C = zero(n, m)
    for i in range(n):
        for j in range(m):
            C[i][j] = fmul(c, A[i][j])
    return C

def svec(c, v):
    out = []
    for x in v:
        out.append(fmul(c, x))
    return out

def vadd(a, b):
    out = []
    for i in range(len(a)):
        out.append(fadd(a[i], b[i]))
    return out

def vsub(a, b):
    out = []
    for i in range(len(a)):
        out.append(fsub(a[i], b[i]))
    return out

def mat_vec(A, v):
    out = []
    for i in range(len(A)):
        s = Fi(0)
        for j in range(len(v)):
            s = fadd(s, fmul(A[i][j], v[j]))
        out.append(s)
    return out

def det2(A):
    return fsub(fmul(A[0][0], A[1][1]), fmul(A[0][1], A[1][0]))

def det3(A):
    a,b,c = A[0]
    d,e,f = A[1]
    g,h,k = A[2]
    t1 = fmul(a, fsub(fmul(e,k), fmul(f,h)))
    t2 = fmul(b, fsub(fmul(d,k), fmul(f,g)))
    t3 = fmul(c, fsub(fmul(d,h), fmul(e,g)))
    return fadd(fsub(t1, t2), t3)

def fmt_vec(v):
    s = "["
    for i in range(len(v)):
        if i > 0:
            s = s + ", "
        s = s + fs(v[i])
    return s + "]"

def fmt_mat(A):
    out = ""
    for i in range(len(A)):
        out = out + "  " + fmt_vec(A[i]) + "\n"
    return out

def row_reduce(M):
    M = [row[:] for row in M]
    rows = len(M)
    cols = len(M[0])
    pr = 0
    for c in range(cols - 1):
        piv = -1
        for r in range(pr, rows):
            if not fis0(M[r][c]):
                piv = r
                break
        if piv == -1:
            continue
        tmp = M[pr]
        M[pr] = M[piv]
        M[piv] = tmp
        pv = M[pr][c]
        for j in range(cols):
            M[pr][j] = fdiv(M[pr][j], pv)
        for r in range(rows):
            if r != pr and not fis0(M[r][c]):
                fac = M[r][c]
                for j in range(cols):
                    M[r][j] = fsub(M[r][j], fmul(fac, M[pr][j]))
        pr = pr + 1
    return M

def solve(A, b):
    rows = len(A)
    cols = len(A[0])
    M = []
    for i in range(rows):
        M.append(A[i][:] + [b[i]])
    R = row_reduce(M)
    for r in range(rows):
        all0 = True
        for c in range(cols):
            if not fis0(R[r][c]):
                all0 = False
        if all0 and not fis0(R[r][cols]):
            return ("none", [])
    piv = {}
    for r in range(rows):
        for c in range(cols):
            if not fis0(R[r][c]):
                piv[c] = r
                break
    free = []
    for c in range(cols):
        if c not in piv:
            free.append(c)
    if len(free) == 0:
        x = [Fi(0) for i in range(cols)]
        for c in piv:
            x[c] = R[piv[c]][cols]
        return ("unique", x)
    part = [Fi(0) for i in range(cols)]
    for c in piv:
        part[c] = R[piv[c]][cols]
    basis = []
    for fc in free:
        v = [Fi(0) for i in range(cols)]
        v[fc] = Fi(1)
        for pc in piv:
            v[pc] = fneg(R[piv[pc]][fc])
        basis.append(v)
    return ("free", [part, basis])

def nullspace(A):
    b = [Fi(0) for i in range(len(A))]
    typ, res = solve(A, b)
    if typ == "unique":
        return []
    if typ == "free":
        return res[1]
    return []

# ---------------- EIGENVALUES ----------------

def char2(A):
    tr = fadd(A[0][0], A[1][1])
    de = det2(A)
    return [Fi(1), fneg(tr), de]

def char3(A):
    tr = fadd(fadd(A[0][0], A[1][1]), A[2][2])
    m00 = fsub(fmul(A[1][1], A[2][2]), fmul(A[1][2], A[2][1]))
    m11 = fsub(fmul(A[0][0], A[2][2]), fmul(A[0][2], A[2][0]))
    m22 = fsub(fmul(A[0][0], A[1][1]), fmul(A[0][1], A[1][0]))
    s2 = fadd(fadd(m00, m11), m22)
    de = det3(A)
    return [Fi(1), fneg(tr), s2, fneg(de)]

def poly_eval(co, x):
    v = Fi(0)
    for c in co:
        v = fadd(fmul(v, x), c)
    return v

def poly_div(co, root):
    out = []
    carry = Fi(0)
    for c in co:
        carry = fadd(fmul(carry, root), c)
        out.append(carry)
    return out[:-1]

def is_square(n):
    if n < 0:
        return -1
    r = int(math.sqrt(n))
    for k in [r-1, r, r+1]:
        if k >= 0 and k*k == n:
            return k
    return -1

def quad_roots(a, b, c):
    D = fsub(fmul(b,b), fmul(Fi(4), fmul(a,c)))
    twoa = fmul(Fi(2), a)
    if D[0] == 0:
        r = fdiv(fneg(b), twoa)
        return [r, r]
    if D[0] > 0:
        prod = D[0] * D[1]
        sq = is_square(prod)
        if sq >= 0:
            sd = F(sq, D[1])
            return [fdiv(fadd(fneg(b), sd), twoa),
                    fdiv(fsub(fneg(b), sd), twoa)]
        # approximate rational fallback
        val = math.sqrt(ffloat(D))
        af = ffloat(a)
        bf = ffloat(b)
        r1 = (-bf + val) / (2*af)
        r2 = (-bf - val) / (2*af)
        return [F(int(round(r1*1000000)), 1000000),
                F(int(round(r2*1000000)), 1000000)]
    # complex is not fully solved in this Nspire short version
    return [("complex",), ("complex",)]

def integer_candidates(n):
    n = abs(int(n))
    if n == 0:
        return [0]
    out = []
    for i in range(1, n+1):
        if n % i == 0:
            out.append(i)
            out.append(-i)
    return out

def roots(co):
    co = co[:]
    out = []
    while len(co) > 1:
        deg = len(co) - 1
        if deg == 1:
            out.append(fdiv(fneg(co[1]), co[0]))
            break
        if deg == 2:
            q = quad_roots(co[0], co[1], co[2])
            out = out + q
            break
        # rational roots only for cubic
        found = None
        # assumes leading coefficient 1 in these classroom cases
        for cand in integer_candidates(co[-1][0]):
            r = Fi(cand)
            if fis0(poly_eval(co, r)):
                found = r
                break
        if found is None:
            break
        out.append(found)
        co = poly_div(co, found)
    return out

def is_complex(x):
    return type(x) == tuple and len(x) == 1 and x[0] == "complex"

def eigenvalues(A):
    if len(A) == 2:
        return roots(char2(A))
    return roots(char3(A))

def eigenvector(A, lam):
    n = len(A)
    B = msub(A, smul(lam, ident(n)))
    ns = nullspace(B)
    if len(ns) == 0:
        return [Fi(0) for i in range(n)]
    return ns[0]

def eigenpairs(A):
    vals = eigenvalues(A)
    out = []
    for l in vals:
        if is_complex(l):
            out.append([l, []])
        else:
            out.append([l, eigenvector(A, l)])
    # sort real values
    real = []
    other = []
    for p in out:
        if is_complex(p[0]):
            other.append(p)
        else:
            real.append(p)
    real.sort(key=lambda p: ffloat(p[0]))
    return real + other

def repeated_info(A):
    ep = eigenpairs(A)
    vals = []
    for p in ep:
        if not is_complex(p[0]):
            vals.append(p[0])
    for i in range(len(vals)):
        count = 0
        for j in range(len(vals)):
            if feq(vals[i], vals[j]):
                count = count + 1
        if count > 1:
            lam = vals[i]
            B = msub(A, smul(lam, ident(len(A))))
            ns = nullspace(B)
            if len(ns) < count:
                return [True, lam, ns]
    return [False, Fi(0), []]

def generalized(A, lam, v):
    B = msub(A, smul(lam, ident(len(A))))
    typ, res = solve(B, v)
    if typ == "unique":
        return res
    if typ == "free":
        return res[0]
    return [Fi(0) for i in range(len(A))]

# ---------------- FORMATTING SOLUTIONS ----------------

def exp_s(lam):
    if fis0(lam):
        return ""
    if feq(lam, Fi(1)):
        return "e^t"
    return "e^(" + fs(lam) + "t)"

def term_const_vec(C, v, lam):
    return C + fmt_vec(v) + exp_s(lam)

def hom_solution(A, show):
    n = len(A)
    if show:
        print("")
        print("STEP 1: Homogeneous system")
        print("Solve Xprime = AX")
        print("A =")
        print(fmt_mat(A))
        if n == 2:
            co = char2(A)
            print("char eq: lambda^2 + (" + fs(co[1]) + ")lambda + (" + fs(co[2]) + ") = 0")
        else:
            co = char3(A)
            print("char eq: lambda^3 + (" + fs(co[1]) + ")lambda^2 + (" + fs(co[2]) + ")lambda + (" + fs(co[3]) + ") = 0")
    rep = repeated_info(A)
    parts = []
    if rep[0]:
        lam = rep[1]
        ns = rep[2]
        v = ns[0]
        w = generalized(A, lam, v)
        if show:
            print("Repeated defective eigenvalue")
            print("lambda = " + fs(lam))
            print("v = " + fmt_vec(v))
            print("Solve (A - lambda I)w = v")
            print("w = " + fmt_vec(w))
        parts.append("C1" + fmt_vec(v) + exp_s(lam))
        parts.append("C2(t" + fmt_vec(v) + " + " + fmt_vec(w) + ")" + exp_s(lam))
        sol = "X(t) = " + " + ".join(parts)
        if show:
            print("Homogeneous solution:")
            print(sol)
        return sol
    ep = eigenpairs(A)
    c = 1
    if show:
        print("Eigenvalues and eigenvectors:")
    for p in ep:
        lam = p[0]
        v = p[1]
        if is_complex(lam):
            if show:
                print("Complex eigenvalue found.")
                print("This Nspire short script does not fully expand complex cases.")
            continue
        if show:
            print("lambda" + str(c) + " = " + fs(lam) + ", v" + str(c) + " = " + fmt_vec(v))
        parts.append("C" + str(c) + fmt_vec(v) + exp_s(lam))
        c = c + 1
    sol = "X(t) = " + " + ".join(parts)
    if show:
        print("Homogeneous solution:")
        print(sol)
    return sol

def particular_const(A, b):
    print("")
    print("STEP 2: Constant forcing")
    print("System: Xprime = AX + b")
    print("b = " + fmt_vec(b))
    print("Try Xp = p")
    print("Then Xpprime = 0")
    print("Substitute: 0 = Ap + b")
    print("So solve Ap = -b")
    nb = []
    for x in b:
        nb.append(fneg(x))
    typ, p = solve(A, nb)
    if typ == "free":
        p = p[0]
    if typ == "none":
        p = [Fi(0) for i in range(len(A))]
        print("No particular solution found.")
    print("p = " + fmt_vec(p))
    print("Xp = " + fmt_vec(p))
    return fmt_vec(p), p

def particular_exp(A, b, k):
    print("")
    print("STEP 2: Exponential forcing")
    print("System: Xprime = AX + b e^(kt)")
    print("b = " + fmt_vec(b))
    print("k = " + fs(k))
    vals = eigenvalues(A)
    print("Check resonance:")
    r = False
    svals = []
    for l in vals:
        if not is_complex(l):
            svals.append(fs(l))
            if feq(l, k):
                r = True
    print("eigenvalues: " + ", ".join(svals))
    if not r:
        print("No resonance because k is not an eigenvalue.")
        print("Try Xp = p e^(kt)")
        print("Differentiate: Xpprime = k p e^(kt)")
        print("Substitute:")
        print("k p e^(kt) = A p e^(kt) + b e^(kt)")
        print("Divide out e^(kt):")
        print("k p = Ap + b")
        print("Move Ap left:")
        print("(kI - A)p = b")
        B = msub(smul(k, ident(len(A))), A)
        print("kI - A =")
        print(fmt_mat(B))
        typ, p = solve(B, b)
        if typ == "free":
            p = p[0]
        if typ == "none":
            p = [Fi(0) for i in range(len(A))]
            print("No particular solution found.")
        print("p = " + fmt_vec(p))
        xp = fmt_vec(p) + "e^(" + fs(k) + "t)"
        print("Xp = " + xp)
        return xp, p
    print("Resonance: k is an eigenvalue.")
    print("Try Xp = (t p + q)e^(kt)")
    print("This short Nspire version prints the setup.")
    print("For many homework problems, solve by adding a factor of t.")
    return "(resonant particular solution)", [Fi(0) for i in range(len(A))]

def component_form(hsol, xpvec, k, mode):
    # For clean component form, only handles nonresonant exponential/constant particular.
    print("")
    print("STEP 3: Component form")
    print("Read each vector entry as x(t), y(t), z(t).")
    names = ["x(t)", "y(t)", "z(t)"]
    print("Use the vector answer above if this line is too compact.")
    # Full symbolic component formatting from arbitrary eigenvectors:
    # rebuild from eigenpairs.
    # This is handled in full_solution below.

def full_solution(A, xp, xpvec, k, kind):
    h = hom_solution(A, False)
    print("")
    print("STEP 3: Full solution")
    full = h
    if xp != "0":
        full = full + " + " + xp
    print(full)
    print("")
    print("STEP 4: Component form")
    ep = eigenpairs(A)
    n = len(A)
    names = ["x(t)", "y(t)", "z(t)"]
    for row in range(n):
        parts = []
        ci = 1
        for p in ep:
            lam = p[0]
            v = p[1]
            if is_complex(lam):
                continue
            coef = v[row]
            if not fis0(coef):
                if feq(coef, Fi(1)):
                    parts.append("C" + str(ci) + exp_s(lam))
                elif feq(coef, Fi(-1)):
                    parts.append("-C" + str(ci) + exp_s(lam))
                else:
                    parts.append(fs(coef) + "C" + str(ci) + exp_s(lam))
            ci = ci + 1
        if kind == "exp":
            coef = xpvec[row]
            if not fis0(coef):
                term = fs(coef) + "e^(" + fs(k) + "t)"
                parts.append(term)
        elif kind == "const":
            coef = xpvec[row]
            if not fis0(coef):
                parts.append(fs(coef))
        if len(parts) == 0:
            line = names[row] + " = 0"
        else:
            line = names[row] + " = " + " + ".join(parts)
        line = line.replace("+ -", "- ")
        print(line)

# ---------------- INPUT ----------------

def read_vec(n, prompt):
    while True:
        s = input(prompt)
        p = s.split()
        if len(p) != n:
            print("Need " + str(n) + " numbers.")
        else:
            return [parse_frac(x) for x in p]

def read_mat(n):
    A = []
    print("Enter matrix rows.")
    for i in range(n):
        A.append(read_vec(n, "row " + str(i+1) + ": "))
    return A

def menu():
    while True:
        print("")
        print("VERBOSE LINEAR SYSTEM ODE SOLVER")
        print("1 Homogeneous Xprime = AX")
        print("2 Nonhomogeneous constant Xprime = AX + b")
        print("3 Nonhomogeneous exponential Xprime = AX + b e^(kt)")
        print("4 Repeated eigenvalue example")
        print("5 Quit")
        ch = input("Choice: ")
        if ch == "1":
            n = int(input("dimension 2 or 3: "))
            A = read_mat(n)
            hom_solution(A, True)
        elif ch == "2":
            n = int(input("dimension 2 or 3: "))
            A = read_mat(n)
            b = read_vec(n, "b vector: ")
            hom_solution(A, True)
            xp, p = particular_const(A, b)
            full_solution(A, xp, p, Fi(0), "const")
        elif ch == "3":
            n = int(input("dimension 2 or 3: "))
            A = read_mat(n)
            k = parse_frac(input("k in e^(kt): "))
            b = read_vec(n, "b vector: ")
            hom_solution(A, True)
            xp, p = particular_exp(A, b, k)
            full_solution(A, xp, p, k, "exp")
        elif ch == "4":
            A = [[Fi(2), Fi(1)], [Fi(0), Fi(2)]]
            print("Example A =")
            print(fmt_mat(A))
            hom_solution(A, True)
            print("Component answer:")
            print("x(t) = C1e^(2t) + C2t e^(2t)")
            print("y(t) = C2e^(2t)")
        elif ch == "5":
            break
        else:
            print("Bad choice")

menu()
